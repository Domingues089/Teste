import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Passos {
    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\thiago.marques\\Desktop\\Dev\\chromedriver-win64.exe");
        WebDriver driver = new ChromeDriver();


        driver.get("https://bugbank.netlify.app/");
         //Cadastro_1
        driver.findElement(By.id("Registrar")).click();
        driver.findElement(By.name("email")).sendKeys("teste01@gmail.com");
        driver.findElement(By.name("name")).sendKeys("Nome01");
        driver.findElement(By.name("password")).sendKeys("Senha01");
        driver.findElement(By.name("passwordConfirmation")).sendKeys("Senha01");
        driver.findElement(By.id("toggleAddBalance")).click();
        driver.findElement(By.name("Cadastrar")).click();
        driver.findElement(By.name("Fechar")).click();

        //login_1
        driver.findElement(By.name("email")).sendKeys("teste01@gmail.com");
        driver.findElement(By.name("password")).sendKeys("Senha01");
        driver.findElement(By.name("Acessar")).click();

        //localiza a conta
        WebElement elemento = driver.findElement(By.id("textAccountNumber"));
        String numero_conta = elemento.getText();

        //Cadastro_2
        driver.findElement(By.id("Registrar")).click();
        driver.findElement(By.name("email")).sendKeys("teste02@gmail.com");
        driver.findElement(By.name("name")).sendKeys("Nome02");
        driver.findElement(By.name("password")).sendKeys("Senha02");
        driver.findElement(By.name("passwordConfirmation")).sendKeys("Senha02");
        driver.findElement(By.id("toggleAddBalance")).click();
        driver.findElement(By.name("Cadastrar")).click();
        driver.findElement(By.name("Fechar")).click();



        // Localizar um elemento e interagir com ele
        WebElement elemento = driver.findElement(By.id("meuElemento"));
        elemento.click();

        // Fechar o navegador
        driver.quit();
    }
}


